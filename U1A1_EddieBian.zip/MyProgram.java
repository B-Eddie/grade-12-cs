/** About Me
Eddie
July 2, 2025
Prints information about me
*/

public class MyProgram
{
    public static void main(String[] args)
    {
        System.out.println("About Me\n");
        System.out.println("Name: Eddie");
        System.out.println("Day school: White Oaks SS (HDSB)");
        System.out.println("Favorite language: Python");
        System.out.println("Favorite sport: Hockey");
        System.out.println("Dream job: Software Engineer");
        System.out.println("Least favorite subject: History");
        System.out.println("Plans in Augest: Study for physics :(");       
    }
}